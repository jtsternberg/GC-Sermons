# GC Sermons #
**Contributors:**      jtsternberg  
**Donate link:**       http://dsgnwrks.pro  
**Tags:**  
**Requires at least:** 4.4  
**Tested up to:**      4.4  
**Stable tag:**        0.1.1  
**License:**           GPLv2  
**License URI:**       http://www.gnu.org/licenses/gpl-2.0.html  

## Description ##

Manage sermons and sermon content in WordPress. The [GC Staff](https://github.com/jtsternberg/GC-Staff) plugin is recommended to complement this plugin for church sites.

**Please note:** you will need to run `composer install` in order to fetch the dependenceis for this plugin/library, **or** you can [download the zip here](https://github.com/jtsternberg/GC-Sermons/blob/master/gc-sermons.zip?raw=true).


## Installation ##

### Manual Installation ###

1. Upload the entire `/gc-sermons` directory to the `/wp-content/plugins/` directory.
2. Activate GC Sermons through the 'Plugins' menu in WordPress.

## Frequently Asked Questions ##


## Screenshots ##


## Changelog ##

### 0.1.0 ###
* First release
