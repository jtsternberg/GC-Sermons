=== GC Sermons ===
Contributors:      jtsternberg
Donate link:       http://dsgnwrks.pro
Tags:
Requires at least: 4.4
Tested up to:      4.9.8
Stable tag:        0.2.1
License:           GPLv2
License URI:       http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Manage sermons and sermon content in WordPress

== Installation ==

= Manual Installation =

1. Upload the entire `/gc-sermons` directory to the `/wp-content/plugins/` directory.
2. Activate GC Sermons through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 0.1.0 =
* First release

== Upgrade Notice ==

= 0.1.0 =
First Release
