<a
	data-sermonid="<?php $this->output( 'sermond_id', 'absint' ); ?>"
	class="gc-sermons-play-button fa <?php $this->output( 'extra_classes', 'esc_attr' ); ?>"
	<?php $this->output( 'style' ); ?>
	href="<?php $this->output( 'video_url', 'esc_url' ); ?>"
>
</a>
