<div class="gc-series-search-results <?php $this->output( 'wrap_classes', 'esc_attr' ); ?>">
	<h2 class="gc-series-search-results-title"><?php $this->output( 'search_notice' ); ?></h2>

	<?php $this->output( 'results' ); ?>
</div>
