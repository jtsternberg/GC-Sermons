# Changelog
All notable changes to this project will be documented in this file.

## [Unreleased][unreleased]

### Enhancements

### Bug Fixes

## 0.1.4 - 2016-05-30

### Enhancements

* Shortcodes, shortcodes, shortcodes. Also, this changelog.
