# GC Sermons Includes #
http://dsgnwrks.pro
Copyright (c) 2016 jtsternberg
Licensed under the GPLv2 license.

Additional PHP functionality goes here.
